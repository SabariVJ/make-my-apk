import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION, u as getRequest } from "./createServerFn-BFFE07zL.mjs";
import { t as createMiddleware } from "./createMiddleware-B_4t7rW1.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/trial.functions-Br-qTa3K.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
var requireSupabaseAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const SUPABASE_URL = processModule.env["SUPABASE_URL"];
	const SUPABASE_PUBLISHABLE_KEY = processModule.env["SUPABASE_PUBLISHABLE_KEY"];
	if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
		const message = `Missing Supabase environment variable(s): ${[...!SUPABASE_URL ? ["SUPABASE_URL"] : [], ...!SUPABASE_PUBLISHABLE_KEY ? ["SUPABASE_PUBLISHABLE_KEY"] : []].join(", ")}. Connect Supabase in Lovable Cloud.`;
		console.error(`[Supabase] ${message}`);
		throw new Error(message);
	}
	const request = getRequest();
	if (!request?.headers) throw new Error("Unauthorized: No request headers available");
	const authHeader = request.headers.get("authorization");
	if (!authHeader) throw new Error("Unauthorized: No authorization header provided");
	if (!authHeader.startsWith("Bearer ")) throw new Error("Unauthorized: Only Bearer tokens are supported");
	const token = authHeader.replace("Bearer ", "");
	if (!token) throw new Error("Unauthorized: No token provided");
	if (token.split(".").length !== 3) throw new Error("Unauthorized: Invalid token");
	const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: {
			fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
			headers: { Authorization: `Bearer ${token}` }
		},
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
	const { data, error } = await supabase.auth.getClaims(token);
	if (error || !data?.claims) throw new Error("Unauthorized: Invalid token");
	if (!data.claims.sub) throw new Error("Unauthorized: No user ID found in token");
	return next({ context: {
		supabase,
		userId: data.claims.sub,
		claims: data.claims
	} });
});
var TRIAL_DAYS = 7;
function buildStatus(row) {
	const start = new Date(row.signup_date).getTime();
	const elapsedDays = Math.floor((Date.now() - start) / 864e5);
	const dayOfTrial = elapsedDays + 1;
	const daysLeft = Math.max(0, TRIAL_DAYS - elapsedDays);
	return {
		userId: row.id,
		email: row.email,
		displayName: row.display_name,
		signupDate: row.signup_date,
		isPlusMember: row.is_plus_member,
		dayOfTrial,
		daysLeft,
		locked: !row.is_plus_member && daysLeft <= 0
	};
}
var getTrialStatus_createServerFn_handler = createServerRpc({
	id: "a337830276c106a455d1da61d2ab55b14e92064fa3f560859692f81378bf99e1",
	name: "getTrialStatus",
	filename: "src/lib/trial.functions.ts"
}, (opts) => getTrialStatus.__executeServer(opts));
var getTrialStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getTrialStatus_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("profiles").select("id, email, display_name, signup_date, is_plus_member").eq("id", context.userId).maybeSingle();
	if (error) throw error;
	if (data) return buildStatus(data);
	const { data: created, error: insertError } = await supabaseAdmin.from("profiles").insert({
		id: context.userId,
		email: context.claims["email"] ?? null
	}).select("id, email, display_name, signup_date, is_plus_member").single();
	if (insertError) throw insertError;
	return buildStatus(created);
});
var unlockPlus_createServerFn_handler = createServerRpc({
	id: "1ee9ef4fc322d0d096e8d75aa648dfe6812a5dd9350f476e5f5c0485b791517c",
	name: "unlockPlus",
	filename: "src/lib/trial.functions.ts"
}, (opts) => unlockPlus.__executeServer(opts));
var unlockPlus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(unlockPlus_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("profiles").update({
		is_plus_member: true,
		plus_unlocked_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", context.userId).select("id, email, display_name, signup_date, is_plus_member").single();
	if (error) throw error;
	return buildStatus(data);
});
//#endregion
export { getTrialStatus_createServerFn_handler, unlockPlus_createServerFn_handler };
