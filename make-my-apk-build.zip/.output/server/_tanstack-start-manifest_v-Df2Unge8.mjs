//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Df2Unge8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/runner/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-WS_LAV8o.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-WS_LAV8o.js"
		} }]
	},
	"/": {
		filePath: "/home/runner/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BSaNGr1B.js"]
	}
} });
//#endregion
export { tsrStartManifest };
